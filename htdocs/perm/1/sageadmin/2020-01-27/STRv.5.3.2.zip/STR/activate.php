<?php
require_once('config_new.php');

// check if request done is POST
if($_SERVER['REQUEST_METHOD'] == "GET"){
	// santitize user input always
	$username = filter_var($_GET['username'],FILTER_SANITIZE_STRING);

	// prepare parameterized statement
	$stmt_select = mysqli_stmt_init();
	
	// if prepared statement is ready
	if(mysqli_stmt_prepare($stmt_select, "SELECT project FROM accounts WHERE username = ?")){
			if(!mysqli_stmt_bind_param($stmt_select,'s',$project,$uname,$yr,$filename,$access,$name,$currdate)){
				echo "Binding parameters failed: ".mysqli_stmt_error($stmt_select); exit;
			}   
			if(!mysqli_stmt_execute($stmt_select)){
				echo "Statment execution failed: ".mysqli_stmt_error($stmt_select); exit;
			}
			$result = mysqli_stmt_get_result($stmt);
		}
		else {echo "Statement preparation failed: ".mysqli_stmt_error($stmt_select); exit;}
	}


	$stmt_insert = mysqli_stmt_init();

	// temporary logic for determining if admin or researcher is the new user 
	// delete or comment this if final logic is done
	if(isset($result) && $result!=4){
		$access = "Admin";
	}
	else{
		$access = "Researcher";
	}

	// final logic: use mysql command to get access type from projects table at str_database 

	// if prepared statement is ready
	if(mysqli_stmt_prepare($stmt_insert, 'UPDATE acccounts SET access=?')){
			if(!mysqli_stmt_bind_param($stmt_insert,'s',$access)){
				echo "Binding parameters failed: ".mysqli_stmt_error($stmt_insert); exit;
			}   
			if(!mysqli_stmt_execute($stmt_insert)){
				echo "Statment execution failed: ".mysqli_stmt_error($stmt_insert); exit;
			}
			echo "<script type='text/javascript'>
			alert('A new document is added successfully');
			window.location = 'file-user.php';
			</script>";
		}
		else {echo "Statement preparation failed: ".mysqli_stmt_error($stmt_insert); exit;}
		}
}
else{
	header('Location: error-pages/403.html');
}
header('Location: login.php');
?>