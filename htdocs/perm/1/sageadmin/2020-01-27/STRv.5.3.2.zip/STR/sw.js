const cacheNAme = 'cache-v1';
const resourcesToPrecache = [
	'/',
	'index.html',
	'styles/main.css',
	'images/img1.jpg',
	'images/img2.jpg',
	'images/img3.jpg'
	];

self.addEventListener('install', event => {
	console.log('Service worker install event!');
	event.waitUntil(
		caches.open(cacheName);
		.then(cache => {
			return cache.addAll(resourcesToPrecache);
		})
	);
});

self.addEventListener('activate', event => {
	console.log('Activate event!');
});

self.addEventListener('fetch', event => {
	console.log('Fetch intecepted for:', event.request.url);
	event.respondWith(caches.match(event.request))
		.then(cachedResponse => {
			return cachedResponse || fetch(event.request);
		})
});



