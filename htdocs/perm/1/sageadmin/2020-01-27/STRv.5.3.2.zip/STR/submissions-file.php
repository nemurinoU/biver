<?php

require_once'config-new.php';

if($_SERVER['REQUEST_METHOD'] == "POST"){
// /////////////////////////////////////////////////////////////
// Sanitize data before usage
$account = filter_var($_POST['account'],FILTER_SANITIZE_NUMBER_INT);
$project = filter_var($_POST['project'],FILTER_SANITIZE_NUMBER_INT);
if(isset($_POST['access'])){ $access = filter_var($_POST['access'],FILTER_SANITIZE_STRING,FILTER_FLAG_STRIP_LOW|FILTER_FLAG_ENCODE_HIGH); }
else{$access = "Researcher";}
if(isset($_POST['username'])){$uname = filter_var($_POST['username'],FILTER_SANITIZE_STRING,FILTER_FLAG_STRIP_LOW|FILTER_FLAG_ENCODE_HIGH);}
else{$uname="USER_UNKNOWN-".date('Y-m-d');}
if(isset($_POST['date'])){$date = filter_var($_POST['year'],FILTER_SANITIZE_STRING,FILTER_FLAG_STRIP_LOW|FILTER_FLAG_ENCODE_HIGH);}
else{$date=date('Y-m-d');}
if(isset($_POST['name'])){$name = filter_var($_POST['name'],FILTER_SANITIZE_STRING,FILTER_FLAG_STRIP_LOW|FILTER_FLAG_ENCODE_HIGH);}
else{$name="PERSON_UNKNOWN-".date('Y-m-d');}
$status = "Pending";

// make new directories if there's no existing one
if(!file_exists("upload")){mkdir("upload"); } 
if(!file_exists("upload/$status")){mkdir("upload/$status"); } 
if(!file_exists("upload/$status/$project")){mkdir("upload/$project"); } 
if(!file_exists("upload/$status/$project/$uname")){mkdir("upload/$project/$uname"); } 
if(!file_exists("upload/$status/$project/$uname/$yr")){mkdir("upload/$project/$uname/$yr"); } 

// /////////////////////////////////////////////////////////////
//Сheck that we have a file
if((!empty($_FILES["uploaded_file"])) && ($_FILES['uploaded_file']['error'] == 0)) {

 //Check if the file is rar folder 
  $filename = basename($_FILES['uploaded_file']['name']);


    //Determine the path to which we want to save this file
      $newname = dirname(__FILE__).'/upload/'.$status.'/'.$project.'/'.$uname.'/'.$yr."/".$filename;
 //Check if the file with the same name is already exists on the server
      if (!file_exists($newname)) {
//--------------------------
	$filename = basename($_FILES['uploaded_file']['name']);
	 $newname = dirname(__FILE__).'/upload/'.$status.'/'.$project.'/'.$uname.'/'.$yr."/".$filename;
	// if file already exists in upload directory
	if (!file_exists($newname)){
		move_uploaded_file($_FILES['uploaded_file']['tmp_name'],$newname);
		//log file inside the database
		$query_stmt = mysqli_stmt_init($con);
		if(mysqli_stmt_prepare($query_stmt, "INSERT INTO submissions (account, project, researcher, organization, submission, submit_date, status, access)  VALUES (?,?,?,?,?,?,?,?)")){
			if(!mysqli_stmt_bind_param($query_stmt,'iissssss',$project,$uname,$org,$filename,$date,$status,$access)){
				echo "Binding parameters failed: ".mysqli_stmt_error($query_stmt); exit;
			}   
			if(!mysqli_stmt_execute($query_stmt)){
				echo "Statment execution failed: ".mysqli_stmt_error($query_stmt); exit;
			}
			echo "<script type='text/javascript'>
			alert('A new document is added successfully');
			window.location = 'file-user.php';
			</script>";
		}
		else {echo "Statement preparation failed: ".mysqli_stmt_error($query_stmt); exit;}
		}
	}
	}
	
}
mysqli_close($con);     
?>
