<!DOCTYPE html>
<?php
	session_start();
?>
<html lang="en">
<!-- necessary meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1, shrink-to-fit=no">
<meta http-equiv="x-ua-compatible" content="ie-edge">
<!-- Bootstrap core CSS-->
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!-- Custom fonts for this template-->
<link href="vendor/fontawesome-free/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<!-- Page level plugin CSS-->
<link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
<!-- Custom styles for this template-->
<link href="css/sb-admin.css" rel="stylesheet">
</html>
<body>
	<main class="row">
		<section class="col-xs-6 jumbotron">
			<h1>Oh no! </h1>
		<em> An error occurred. </em><br>
		<p>
			<?php 
			if(isset($_SESSION['error-message']))
				{ echo $_SESSION['error-message']; }
			else{
				echo "<p> Joke! There's none. Keep up the good work! </p>";
			}
			echo "<a href='".$_SESSION['redirect-url']."'> Go back </a>"
			?>  </p> 
		</section>
		
	</main>
</body>
<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<!-- Custom scripts for this page-->