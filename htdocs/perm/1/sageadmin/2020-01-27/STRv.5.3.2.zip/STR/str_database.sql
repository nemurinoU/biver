-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 05, 2019 at 02:32 PM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `str_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
CREATE TABLE IF NOT EXISTS `account` (
  `AccountID` varchar(99) NOT NULL,
  `ProjectID` varchar(99) NOT NULL,
  `OrganizationID` varchar(99) NOT NULL,
  `Name` varchar(99) NOT NULL,
  `Project` varchar(99) NOT NULL,
  `Organization` varchar(99) NOT NULL,
  `Email` varchar(99) NOT NULL,
  `CellNum` varchar(99) NOT NULL,
  `password` varchar(99) NOT NULL,
  `AccessType` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`AccountID`, `ProjectID`, `OrganizationID`, `Name`, `Project`, `Organization`, `Email`, `CellNum`, `password`, `AccessType`) VALUES
('19-12-001', '004', '001', 'Shann Aurelle G. Ripalda', 'Project 4', 'Philippine Science High School - Eastern Visayas Campus', 'shannaurelleg@gmail.com', '09451187497', 'admin1', 'Admin'),
('19-12-002', '004', '001', 'Michael Sean Brian Omisol', 'Project 4', 'Philippine Science High School - Eastern Visayas Campus', 'random_email@gmail.com', '09092321157', 'admin2', 'Admin'),
('19-12-003', '004', '001', 'Lawrence Ardee M. Canillas', 'Project 4', 'Philippine Science High School - Eastern Visayas Campus', 'random_email@gmail.com', '09099991122', 'admin3', 'Admin'),
('14-08-001', '002', '001', 'Renoir', 'Project 2', 'PSHS-EVC', 'msbbno@gmail.com', '09082621186', 'project1', 'Project Head'),
('14-08-002', '003', '001', 'Joseph', 'Project 3', 'PSHS-EVC', 'mxh@gmail.com', '09080123212', 'project2', 'Project Head'),
('15-08-001', '002', '001', 'Sean Brian', 'Project 2', 'PSHS-EVC', 'seanbrain@gmail.com', '0912312412', 'research1', 'Researcher'),
('14-08-003', '003', '001', 'History', 'Project 3', 'PSHS-EVC', 'youtube@hotmail.com', '0909009090', 'research2', 'Researcher');

-- --------------------------------------------------------

--
-- Table structure for table `datasets`
--

DROP TABLE IF EXISTS `datasets`;
CREATE TABLE IF NOT EXISTS `datasets` (
  `SubmissionID` varchar(255) NOT NULL,
  `ScientificName` varchar(255) NOT NULL,
  `Orderr` varchar(255) NOT NULL,
  `Class` varchar(255) NOT NULL,
  `Genus` varchar(255) NOT NULL,
  `Species` varchar(255) NOT NULL,
  `SpeciesEpithet` varchar(255) NOT NULL,
  `Subspecies` varchar(255) NOT NULL,
  `Collector` varchar(255) NOT NULL,
  `CollectorID` varchar(255) NOT NULL,
  `Location` varchar(255) NOT NULL,
  `YearOfCollection` varchar(255) NOT NULL,
  `MonthOfCollection` varchar(255) NOT NULL,
  `DayOfCollection` varchar(255) NOT NULL,
  `GPSLocation` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `datasets`
--

INSERT INTO `datasets` (`SubmissionID`, `ScientificName`, `Orderr`, `Class`, `Genus`, `Species`, `SpeciesEpithet`, `Subspecies`, `Collector`, `CollectorID`, `Location`, `YearOfCollection`, `MonthOfCollection`, `DayOfCollection`, `GPSLocation`) VALUES
('1-1', 'Oedipus oedipus', 'MILF Hunter', 'Legendary', 'Humanoid', 'Homo', 'Homoerectur', 'Ano Ito', 'Michael', '14-064-2018', 'Cotabato', '2019', 'April', '14', 'SOMETHWERE');

-- --------------------------------------------------------

--
-- Table structure for table `edit_datasets`
--

DROP TABLE IF EXISTS `edit_datasets`;
CREATE TABLE IF NOT EXISTS `edit_datasets` (
  `SubmissionID` varchar(255) NOT NULL,
  `ScientificName` varchar(255) NOT NULL,
  `Orderr` varchar(255) NOT NULL,
  `Class` varchar(255) NOT NULL,
  `Genus` varchar(255) NOT NULL,
  `Species` varchar(255) NOT NULL,
  `SpeciesEpithet` varchar(255) NOT NULL,
  `Subspecies` varchar(255) NOT NULL,
  `Collector` varchar(255) NOT NULL,
  `CollectorID` varchar(255) NOT NULL,
  `Location` varchar(255) NOT NULL,
  `YearOfCollection` varchar(255) NOT NULL,
  `MonthOfCollection` varchar(255) NOT NULL,
  `DayOfCollection` varchar(255) NOT NULL,
  `GPSLocation` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `edit_datasets`
--

INSERT INTO `edit_datasets` (`SubmissionID`, `ScientificName`, `Orderr`, `Class`, `Genus`, `Species`, `SpeciesEpithet`, `Subspecies`, `Collector`, `CollectorID`, `Location`, `YearOfCollection`, `MonthOfCollection`, `DayOfCollection`, `GPSLocation`) VALUES
('1-1', '', '', '', 'asdasd', '', '', '', '', '', '', '', 'asdasd', '', 'asdasd');

-- --------------------------------------------------------

--
-- Table structure for table `submissions`
--

DROP TABLE IF EXISTS `submissions`;
CREATE TABLE IF NOT EXISTS `submissions` (
  `AccountID` varchar(255) NOT NULL,
  `ProjectID` varchar(255) NOT NULL,
  `Organization` varchar(255) NOT NULL,
  `Submission` varchar(255) NOT NULL,
  `Contact` varchar(255) NOT NULL,
  `Status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `submissions`
--

INSERT INTO `submissions` (`AccountID`, `ProjectID`, `Organization`, `Submission`, `Contact`, `Status`) VALUES
('19-12-001\r\n', '004', 'PSHS-EVC', 'Computer etc...', 'random_email@gmail.com', 'Pending'),
('19-12-001\r\n', '004', 'PSHS-EVC', 'Computer etc...', 'random_email@gmail.com', 'Pending'),
('19-12-002', '004', 'PSHS-EVC', 'Data Report', 'random_email@gmail.com', 'Pending'),
('14-08-003', '003', 'PSHS-EVC', 'Data Report', 'random_email@gmail.com', 'Pending');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
