<!-- 
	Google Drive-like file management webpage

	It has five features:
	File Deletion
	File Addition
	File Rename
	Edit Permissions  

	How to code this:
	1. Web design
	2. Back-end code
	3. Optimization for crawlers and search engines

-->
<!DOCTYPE html>
<html>
<!-- header -->
<head>
<!-- important metas -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Bootstrap core CSS-->
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!-- Custom fonts for this template-->
<link href="vendor/fontawesome-free/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<!-- Page level plugin CSS-->
<link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
<!-- Custom styles for this template-->
<link href="css/sb-admin.css" rel="stylesheet">
<!-- on-page stylesheet -->
<style>
	.bg-0{
		background: transparent;
	}
	.bg-grey{
		background-color: #F5F5F5;
	}
</style>
</head>
<!-- body of the web app -->
<body>
<!-- top navigation -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top" id="mainNav">

<a class="navbar-brand" href="index.php"><img src='favicon.ico' alt="biver logo"> BiVER</a>
<button class="navbar-toggler navbar-toggler-right p-2" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarResponsive">
<ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
<li class="nav-item" data-toggle="tooltip" data-placement="right p-2" title="See relevant business stats">
<a class="nav-link" href="index.php">
<i class="fa fa-fw fa-dashboard"></i>
<span class="nav-link-text">Dashboard</span>
</a>
</li>
<li class="nav-item" data-toggle="tooltip" data-placement="right p-2" title="Include a new product">
<a class="nav-link" href="product.php">
<i class="fa fa-check-square"></i>
<span class="nav-link-text">Create Product</span>
</a>
</li>
<li class="nav-item" data-toggle="tooltip" data-placement="right p-2" title="Add new users to the system">
<a class="nav-link" href="register.php">
<i class="fa fas fa-user"></i>
<span class="nav-link-text">Register Users</span>
</a>
</li>
<li class="nav-item" data-toggle="tooltip" data-placement="right p-2" title="Accept orders and refunds">
<a class="nav-link" href="pos.php">
<i class="fa fas fa-money"></i>
<span class="nav-link-text">POS</span>
</a>
</li>
</ul>
<ul class="navbar-nav ml-auto">

<li class="nav-item">
<form class="form-inline my-2 my-lg-0 mr-lg-2">
<div class="input-group">
<input class="form-control" type="text" placeholder="Search for...">
<span class="input-group-append">
<button class="btn btn-primary" type="button">
<i class="fa fa-search"></i>
</button>
</span>
</div>
</form>
</li>
<li class="nav-item">
<a class="nav-link" data-toggle="modal" data-target="#exampleModal" href='logout.php'>
<i class="fa fa-fw fa-sign-out"></i></a>
</li>
</ul>
</div>
</nav>
<!-- body of the file manager -->
<main class="p-0">
<header class="container-fluid border-bottom">
	<h5 class="p-2"><strong> Folder Name</strong></h5>
</header> 
<section class="container-fluid row">
	<article id="toolbar" class="d-md-block col-md-4 col-lg-3 border-right border-left p-0" hidden>
		<button class='d-block btn btn-white container-fluid border-bottom p-4 text-left'>
			<i class="fa fa-file mr-2"></i>
			<label for='newfile'><strong>New File</strong></label>
		</button>
		<button class='d-block btn btn-white container-fluid border-bottom p-4 text-left'>
			<i class="fa fa-folder mr-2"></i> 
			<label for='newfolder'><strong>New Folder</strong></label>
		</button>
		<button class='d-block btn btn-white container-fluid border-bottom p-4 text-left'>
			<i class="fa fa-check mr-2"></i> 
			<label for='approval'><strong>Approve new File</strong></label>
		</button>
	</article>
	<article id="filelist" class="container-fluid col-xs-12 col-md-8 col-lg-9 p-0">
		<button class='d-block btn btn-white container-fluid border-bottom p-4 text-left'> File 1</button>
		<button class='d-block btn btn-white container-fluid border-bottom p-4 text-left'> File 2</button>
		<button class='d-block btn btn-white container-fluid border-bottom p-4 text-left'> File 3</button>
	</article>
	<article id="info" class="d-xs-none d-sm-none d-md-none col-lg-3" hidden>
		<div class="container-fluid"><img class='img-responsive p-4 center-block' src='favicon.ico' alt='fileimg'></div>
		<table>
			<thead>
				<th class="card-title"><h6>File 1</h6></th>
			</thead>
			<tbody>
				<tr scope='row'>
					<td class="border-right p-2"><label for='name' sr-only></label>Name</td>
					<td class="p-2"><label for='field1'>File 1</label></td>
				</tr>
				<tr>
					<td class="border-right p-2"><label for='file_size' sr-only></label>File size</td>
					<td class="p-2"><label for='field2'>47.80 kiB</label></td>
				</tr>
				<tr>
					<td class="border-right p-2"><label for='file_type' sr-only></label>File type</td>
					<td class="p-2"><label for='field3'>Php extension file</label></td>
				</tr>
				<tr>
					<td class="border-right p-2"><label for='last_modified' sr-only></label>Last modified</td>
					<td class="p-2"><label for='field4'>January 1, 2018</label></td>
				</tr>
				<tr>
					<td class="border-right p-2"><label for='owner' sr-only></label>Owner</td>
					<td class="p-2"><label for='field5'>Yamerrrooo</label></td>
				</tr>
				<tr scope='row'>
					<td class="border-right p-2"><label for='description' sr-only></label>Description</td>
					<td class="p-2"><label for='field6'>A nice file lmao</label></td>
				</tr>
			</tbody>
		</table>
	</article>
</section>
</main>
</body>
