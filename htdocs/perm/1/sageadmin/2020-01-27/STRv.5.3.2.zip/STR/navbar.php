<head>
<style>
	.img-h{
				width:50px;
				height:50px;
				position: relative;
				bottom:5px;
			}
</style>
</head>
<div class="jumbotron text-center" style="margin-bottom: 0px" id="header">		
			<img style="display: inline-block" class="img-h" src="pcaarrd.jpg"/><h2 style="display: inline-block" class="mx-2">Biodiversity and Vulnerable Ecosystems Research</h2><img style="display: inline-block" class="img-h" src="crestLogo.png"/><img style="display: inline-block" class="img-h ml-2" src="pshsevc.png"/>
		</div>
		<!-- ------------------------------------------------------------<NAVBAR>------------------------------------------------------- -->

		<!-- ----------------------------------------------------------<UPPER NAVBAR>---------------------------------------------------- -->
		<nav class="navbar navbar-expand-md navbar-dark mb-0 sticky-top navBar1 py-0">
			<a class="navbar-brand" href="#"><img src="logoTemp.png" class="logo"><span id="brandTitle">BiVER</span></a>
					
			<button class="navbar-toggler" data-toggle="collapse" data-target="#collapse_target">
				<span class="navbar-toggler-icon"></span>
			</button>
				
			<div class="collapse navbar-collapse" id="collapse_target">

		<!-- ------------------------------------------------------------<PROFILE>------------------------------------------------------- -->
				<ul class="navbar-nav mr-auto">
				    <li class="nav-item">
						<a class="nav-link" href="#" id="profile">
						<img src="profilePic.png" class="dp">&nbsp;&nbsp; Username</a>
					</li>
				</ul>
		<!-- ------------------------------------------------------------<PROFILE/>------------------------------------------------------ -->
				<ul class="navbar-nav ml-auto">
					<li class="nav-item d-md-none">
						<a class="nav-link" href="Members.php" id="members">Members <i class="fas fa-user"></i></a>
					</li>
					<li class="nav-item d-md-none">
						<a class="nav-link" href="Updates.php" id="updates">Updates <i class="fas fa-user-edit"></i></a>
					</li>
					<li class="nav-item">
						<a class="nav-link d-md-none" href="entry_researcher.php" id="submissions">Add Submission <i class="fas fa-user-edit"></i></a>
					</li>					
					<li class="nav-item d-md-none">
						<a class="nav-link" href="datasets.php" id="datasets">Datasets</a>
					</li>		
					<li class="nav-item">
						<a class="nav-link" href="activities.php" id="activities">Activities <i class="fas fa-running"></i></a>
					</li>
					<!--
					<li class="nav-item">
						<a class="nav-link" href="#" id="contactUs">Contact Us <i class="fas fa-phone"></i></a>
					</li>
					-->
					<li class="nav-item">
						<a class="nav-link" href="#">Publications</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#">Announcements</a>
					</li>			
					<li class="nav-item" id="something">
						<a class="nav-link"  href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
					</li>
					<li class="nav-item" id= "login">
						<a class="nav-link"  href="login.php" ><i class="fas fa-sign-in-alt"></i> Login</a>
					</li>
				</ul>

			</div>		
		</nav>
		<!-- ----------------------------------------------------------<UPPER NAVBAR/>---------------------------------------------------- -->
		
		<!-- ----------------------------------------------------------<LOWER NAVBAR>---------------------------------------------------- -->
		<!--
		<nav class="navBar2 navbar navbar-expand-md navbar-dark mb-0 sticky-top d-none d-md-flex shadow">		
			<div class="collapse navbar-collapse flex-column ml-lg-0 ml-3" id="navbarCollapse">
   	        	<ul class="navbar-nav mx-auto mb-1 unav">						
					<li class="nav-item">
						<a class="nav-link py-0 mx-2" href="Members.php" id="members">Members <i class="fas fa-user"></i></a>
					</li>
					<li class="nav-item">
						<a class="nav-link py-0 mx-2" href="Updates.php" id="updates">Updates <i class="fas fa-user-edit"></i></a>
					</li>
					<li class="nav-item">
						<a class="nav-link py-0 mx-2" href="entry_researcher.php" id="submissions">Add Submission <i class="fas fa-user-edit"></i></a>
					</li>					
					<li class="nav-item">
						<a class="nav-link py-0 mx-2" href="datasets.php" id="datasets">Datasets</a>
					</li>														
				</ul>
	            <ul class="navbar-nav flex-row text-center bnav p-0" style="font-size:15px">
	                <li class="nav-item col-md-4 p-0 border-right border-light">
	                    <a class="nav-link py-0 pr-3" href="#">Biodiversity and systematics study of organisms in vulnerable ecosystems</a>
	                </li>
	                <li class="nav-item col-md-4 p-0">
	                    <a class="nav-link py-0 pr-3" href="#">Assessment of quality of water systems in Eastern Visayas</a>
	                </li>
	                <li class="nav-item col-md-4 p-0 border-left border-light">
	                    <a class="nav-link py-0 pr-3" href="#">Computational Model of the Characteristics of the Binahaan River Ecosystem</a>
	                </li>
	            </ul>
        	</div>
		</nav>
		-->
		<!-- ----------------------------------------------------------<LOWER NAVBAR/>--------------------------------------------------- -->
		
		<!-- ------------------------------------------------------------<NAVBAR/>------------------------------------------------------- -->

		<!-- ------------------------------------------------------------<PROJECTS>------------------------------------------------------- -->
		<!--
		<div class="container-fluid padding">
			<div class="row padding text-center projects">
				<a  class="col-xs-12 col-sm-6 col-md-4 nounderline row-eq-height" href="#" data-toggle="tooltip" data-placement="bottom" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas bibendum ac felis id commodo. Etiam mauris purus, fringilla id tempus in, mollis vel orci. Duis ultricies at erat eget iaculis.">
				<div class="box position-relative shadow-lg px-3">								
					<h5>Biodiversity and systematics of organisms in vulnerable ecosystems</h5>
					
									
				</div>				
				</a>
				<a  class="col-xs-12 col-sm-6 col-md-4 nounderline row-eq-height position-relative" href="#" data-toggle="tooltip" data-placement="bottom" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas bibendum ac felis id commodo. Etiam mauris purus, fringilla id tempus in, mollis vel orci. Duis ultricies at erat eget iaculis.">			
					<div class="box position-relative shadow-lg px-3">
						<h5>Assessment of quality of water systems in Eastern Visayas</h5>
						
											
					</div>
				</a>
				<a  class="col-xs-12 col-sm-12 col-md-4 nounderline row-eq-height position-relative" href="#" data-toggle="tooltip" data-placement="bottom" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas bibendum ac felis id commodo. Etiam mauris purus, fringilla id tempus in, mollis vel orci. Duis ultricies at erat eget iaculis.">				
					<div class="box position-relative shadow-lg px-3">
						<h5>A Computational Model of the Characteristics of the Binahaan River Ecosystem</h5>
						
						
					</div>
			   </a>
			</div>
		</div>
		--!>