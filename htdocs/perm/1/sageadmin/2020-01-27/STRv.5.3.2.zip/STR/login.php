<?php
	$con=mysqli_connect("localhost", "root", "");
	if (mysqli_connect_errno()){
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	else{
		mysqli_select_db($con, 'str_database');
		if(isset($_POST['submit'])){
			// sanitize variables
			$password = filter_var($_POST['pass'],FILTER_SANITIZE_STRING);
			$username = filter_var($_POST['username'],FILTER_SANITIZE_STRING);
			
			$stmt = mysqli_stmt_init($con);

			// if prepared statement is ready
			if(mysqli_stmt_prepare($stmt, "select * from accounts where username=?")){
				// if variables are not binded to parameters properly, display error message and exit code
				if(!mysqli_stmt_bind_param($stmt,'s',$username)){
					echo "Binding parameters failed: ".mysqli_stmt_error($stmt); exit;
				}
				// if prepared statement fails to execute, display error message and exit code
				if(!mysqli_stmt_execute($stmt)){
					echo "Statement execution failed: ".mysqli_stmt_error($stmt); exit;
					$result = mysqli_stmt_get_result($stmt);
				}
				$result = "";
			}
			// send error message instead if preparation of statement failed
			else {echo "Statement preparation failed: ".mysqli_stmt_error($stmt); exit;} 

			header($link);

			if(password_verify($password, $result['password'])){
				$data = mysqli_fetch_assoc($result);
				$_SESSION['active'] = "True";
				$_SESSION['access'] = $data['access'];
			}
		}
	}	
?>

<!DOCTYPE html>
<html>
<head>
	<title>BiVER</title>

		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<!-- ------------------------------------------------------------<Bootstrap CDN>------------------------------------------------------- -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/js/bootstrap.bundle.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

		<!-- ------------------------------------------------------------<Bootstrap CDN/>------------------------------------------------------ -->

		<!-- -----------------------------------------------------------<Fonts and Icons>------------------------------------------------------ -->
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
		<link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
		<!-- -----------------------------------------------------------<Fonts and Icons/>----------------------------------------------------- -->

		<!-- ----------------------------------------------------------<Icon Header & Styling>-------------------------------------------------- -->
		<link href="style.css" rel="stylesheet">
		<link rel="icon" href="favicon.ico" type="image/x-icon">
		<link rel="shortcut icon" href="favicon.ico" type="image/ico">
		<!-- ---------------------------------------------------------<Icon Header & Styling/>-------------------------------------------------- -->
		<style>
			
			#loginBody{
				border-radius:20px;
			}
			.loginBox{
				color:white;
				padding-top: 20px;
				padding-bottom: 15px;
				padding-left: 30px;
				padding-right: 30px;
				border-radius: 0px;
				height:100%;
			}
			#datasetH{
			  padding-left: 10px;
			  padding-right: 10px;
			  padding-bottom: 20px;
			  background-color: #174912;
			}
			
		    #aboutBiver{
			color: black;
			background-color: white;
			margin-top: 20px;
			font-family: Verdana;
			}
			.row-eq-height {
			  display: -webkit-box;
			  display: -webkit-flex;
			  display: -ms-flexbox;
			  display:         flex;
			}
			#partner{
				color:black;
				background:none;
				text-align: center; 
			
			}
			.page-footer{
			  color:white;
			  background-color:#005208;
			  height:120px; 
			  padding-top: 20px;
			  padding-left: 10px;
			}
			#header{
				background:none;
				font-family: 'Ubuntu', sans-serif;
			}
			#whatweoffer{
				background-color: #1f1f1f;
				color:white;
			}
			#datasetH{
			  padding-left: 10px;
			  padding-right: 10px;
			  padding-bottom: 20px;
			  background-color: #174912;
			}
			#publicationH{
				font-size:20px;
				background-color: #377f30;
			}
			.nounderline {
			  	text-decoration: none !important
			}
			
			h5{
				font-size:21px;

			}
			#projectImage{
				width:100%;
				height:auto;
			}
			img.agency{
				height: 200px;
				width: 200px;
			}
			.agency{
				margin-top:10px;
			}
			.calculated-width {
			    width: -webkit-calc(100% - 60px);
			    width:    -moz-calc(100% - 60px);
			    width:         calc(100% - 60px);
			}​
			div.tooltip-inner {
			    max-width: 250px;
			}
			.box{
				background-color: #009432;
			}
			.row2{
				background-color: #2f3640;
				color:white;
			}
			.tempPic{
				background-color: #4cd137;
				width:100%;
			}
			.row4{
				background-color: #095b20;
				color:white;
			}
			.vertical-center {

			    display: flex;
			    align-items: center;
			}
			.boxS{
				  background-color: #2c3e50;
				  color: white;
				  border-radius: 20px;
				  padding-bottom: 10px;
				  padding-top: 10px;
			}
			/*-----------------------------------------<Hompage Styling/>----------------------------------------------*/

			/*-----------------------------------------<PHP CODE>----------------------------------------------*/
			#members{
				<?php 
					if(isset($_SESSION['active'])){
						echo "display: block;";
					}
					else {
						echo "display: none;";
					}
				?>
			}
			#updates{
				<?php 
					if(isset($_SESSION['active']))
						if($_SESSION['type']=="Admin" || $_SESSION['type']=="Project Head"){
							echo "display: block;";
						}
						else{
							echo "display: none;";
						}
					else {
						echo "display: none;";
					}
				?>
			}
			#submissions{
				<?php 
					if(isset($_SESSION['active'])){
						if ($_SESSION['type']=="Researcher"){
							echo "display: block;";
						}
						else{
							echo "display: none;";
						}
					}
					else {
						echo "display: none;";
					}
				?>
			}
			#login{
				<?php 
					if(isset($_SESSION['active'])){
						echo "display: none;";
					}
					else {
						echo "display: block;";
					}
				?>
			}
			#something{
				<?php 
					if(isset($_SESSION['active'])){
						echo "display: block;";
					}
					else {
						echo "display: none;";
					}
				?>
			}
			#bar2{
				<?php 
					if(isset($_SESSION['active'])){
						echo "display: block;";
					}
					else {
						echo "display: none;";
					}
				?>
			}
			#datasets{
				<?php 
					if(isset($_SESSION['active'])){
						echo "display: block;";
					}
					else {
						echo "display: none;";
					}
				?>
			}
			#profile{
				<?php 
					if(isset($_SESSION['active'])){
						echo "display: block;";
					}
					else {
						echo "display: none;";
					}
				?>
			}
			/*-----------------------------------------<PHP CODE/>----------------------------------------------*/
		
			/*-----------------------------------------<navbar>----------------------------------------------*/
			.navBar1{
				font-size:16px;
				background-color: #2c3e50;
			}
			.navBar2{
				font-size:16px;
				max-height:45px;
				top:55px;
				background-color: #00695C;
			}			
			img.logo{
				width:57px;
				height:29px;
				position:relative;
				bottom:5px;
			}
			#brandTitle{
				font-size:30px;
			}
			.navbar-light{
				color:black;
			}
			.dp{
				width:40px;
				height:40px;
			}
			/*-----------------------------------------<navbar/>----------------------------------------------*/
		</style>
</head>
<body>
		<?php include('navbar.php'); ?>
		<!-- ----------------------------------------------------------<LOWER NAVBAR/>--------------------------------------------------- -->

		<!-- ------------------------------------------------------------<NAVBAR/>------------------------------------------------------- -->
		<h2 class="text-center mt-3">LOGIN</h2><br>
		<div class="container-fluid padding">
			<div class="row text-center padding mx-1">
				<div class="col-md-2"></div>
				<div class="col-xs-12 col-sm-6 col-md-4 mr-0 rounded-left border-right-1 border border-white shadow-lg" style="background-color: #262729">
					<div class="loginBox">
						<div id="login">
							<form action="<?php $_PHP_SELF;?>" method="post">
							  <div class="form-group">
							    <label for="exampleInputEmail1">Username</label>
							    <input type="text" class="form-control" id="username" name="username" placeholder="">
							    <!-- <small id="emailHelp" class="form-text text-muted">Never share your BiVER ID with anyone else.</small> -->
							  </div>
							  <div class="form-group">
							    <label for="exampleInputPassword1">Password</label>
							    <input type="password" class="form-control" id="pass" name="pass" placeholder="">
							  </div>
							  <button type="submit" id="submit" name="submit" class="btn btn-primary">Login</button>
							</form>
						</div>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-4 text-left ml-0 rounded-right border-left-1 border border-white shadow-lg" style="background-color: #262729">
					<div class="loginBox">		

							<br><br>	
							<h3 class="text-center mb-3 align-middle">Contribute to BiVER?</h3>	
							<a href="register.php" class="nounderline">
								<button type="submit" id="submit" name="submit" class="btn btn-primary d-block mx-auto">Register Here</button>
							</a>
						
					</div>
				</div>
				<div class="col-md-2"></div>
			</div>
		</div>
	<br><br><br>
</body>
<script type="text/javascript">

			
			

			$(document).ready(function(){
  				$('[data-toggle="tooltip"]').tooltip(); 
			});

			$(document).ready(function () {
			  	$("a").tooltip({
			    'selector': '',
			    'placement':'top',
			    'container':'body'
			  	});
			});

			(function ($) {
				
			  	$(document).ready(function(){

			  		var counter = 0;

			  		$(".bnav").hide();
			  		$('.bnav').fadeIn();
					$( ".bnav" ).animate({ "max-height": "200px" }, "slow" );
			
				});
			}(jQuery));

		
		</script>
</html>