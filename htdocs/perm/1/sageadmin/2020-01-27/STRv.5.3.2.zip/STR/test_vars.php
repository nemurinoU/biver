<?php
$_SESSION['account'] = 1;
$_SESSION['username'] = "biveradmin";
$_SESSION['project'] = 4;
$_SESSION['org'] = "Philippine Science High School - Eastern Visayas Campus";
$_SESSION['submit_date'] = date('Y-m-d');
$_SESSION['status'] = "Accepted";
$_SESSION['access'] = "Admin";
?>