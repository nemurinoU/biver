<?php

require_once'config-new.php';

if($_SERVER['REQUEST_METHOD'] == "POST"){
// /////////////////////////////////////////////////////////////
// Sanitize data before usage

if(isset($_POST['project'])){ $project = filter_var($_POST['project'],FILTER_SANITIZE_STRING,FILTER_FLAG_STRIP_LOW|FILTER_FLAG_ENCODE_HIGH);}
else{$project = "Project 4";}
if(isset($_POST['access'])){ $access = filter_var($_POST['access'],FILTER_SANITIZE_STRING,FILTER_FLAG_STRIP_LOW|FILTER_FLAG_ENCODE_HIGH); }
else{$access = "Researcher";}
if(isset($_POST['username'])){$uname = filter_var($_POST['username'],FILTER_SANITIZE_STRING,FILTER_FLAG_STRIP_LOW|FILTER_FLAG_ENCODE_HIGH);}
else{$uname="USER_UNKNOWN-".date('Y-m-d');}
if(isset($_POST['year'])){$yr = filter_var($_POST['year'],FILTER_SANITIZE_STRING,FILTER_FLAG_STRIP_LOW|FILTER_FLAG_ENCODE_HIGH);}
else{$yr=date('Y-m-d');}
if(isset($_POST['name'])){$yr = filter_var($_POST['name'],FILTER_SANITIZE_STRING,FILTER_FLAG_STRIP_LOW|FILTER_FLAG_ENCODE_HIGH);}
else{$name="PERSON_UNKNOWN-".date('Y-m-d');}
$currdate = date('Y-m-d');

// make new directories if there's no existing one
if(!file_exists("upload")){mkdir("upload"); } 
if(!file_exists("upload/$project")){mkdir("upload/$project"); } 
if(!file_exists("upload/$project/$uname")){mkdir("upload/$project/$uname"); } 
if(!file_exists("upload/$project/$uname/$yr")){mkdir("upload/$project/$uname/$yr"); } 

// /////////////////////////////////////////////////////////////
//Сheck that we have a file
if((!empty($_FILES["uploaded_file"])) && ($_FILES['uploaded_file']['error'] == 0)) {

 //Check if the file is rar folder 
  $filename = basename($_FILES['uploaded_file']['name']);


    //Determine the path to which we want to save this file
      $newname = dirname(__FILE__).'/upload/'.$project.'/'.$uname.'/'.$yr."/".$filename;
 //Check if the file with the same name is already exists on the server
      if (!file_exists($newname)) {
//--------------------------
	$filename = basename($_FILES['uploaded_file']['name']);
	 $newname = dirname(__FILE__).'/upload/'.$project.'/'.$uname.'/'.$yr."/".$filename;
	// if file already exists in upload directory
	if (!file_exists($newname)){
		move_uploaded_file($_FILES['uploaded_file']['tmp_name'],$newname);
		//log file inside the database
		$query_stmt = mysqli_stmt_init($con);
		if(mysqli_stmt_prepare($query_stmt, 'INSERT INTO filelist (field2, field3, field4, field5, field6, field7, field8)  VALUES (?,?,?,?,?,?,?)')){
			if(!mysqli_stmt_bind_param($query_stmt,'sssssss',$project,$uname,$yr,$filename,$access,$name,$currdate)){
				echo "Binding parameters failed: ".mysqli_stmt_error($query_stmt); exit;
			}   
			if(!mysqli_stmt_execute($query_stmt)){
				echo "Statment execution failed: ".mysqli_stmt_error($query_stmt); exit;
			}
			echo "<script type='text/javascript'>
			alert('A new document is added successfully');
			window.location = 'file-user.php';
			</script>";
		}
		else {echo "Statement preparation failed: ".mysqli_stmt_error($query_stmt); exit;}
		}
	}
	}
	
}
mysqli_close($con);     
?>
