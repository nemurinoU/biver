<?php
session_start();

require_once("config-new.php");

if(isset($_SESSION['upload-success'])){
	echo "<script type='text/javascript>
	alert('File upload successful!');
	</script>";
	unset($_SESSION['upload-success']);
}
?>
<!DOCTYPE html>
<html>
<head>
<!-- Bootstrap core CSS-->
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!-- Custom fonts for this template-->
<link href="vendor/fontawesome-free/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<!-- Page level plugin CSS-->
<link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
<!-- Custom styles for this template-->
<link href="css/sb-admin.css" rel="stylesheet">

<style>
	.bg-0{
		background: transparent;
	}
</style>
</head>
<?php
if (isset($_SESSION['username'])) {
	$user = $_SESSION['username'];
?>
<body class="content-wrapper fixed-nav sticky-footer" id="page-top">
<!-- Navigation-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
<a class="navbar-brand" href="index.php">AlphaAdmin</a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarResponsive">
<ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
<li class="nav-item" data-toggle="tooltip" data-placement="right" title="See relevant business stats">
<a class="nav-link" href="index.php">
<i class="fa fa-fw fa-dashboard"></i>
<span class="nav-link-text">Dashboard</span>
</a>
</li>
<li class="nav-item" data-toggle="tooltip" data-placement="right" title="Include a new product">
<a class="nav-link" href="product.php">
<i class="fa fa-check-square"></i>
<span class="nav-link-text">Create Product</span>
</a>
</li>
<li class="nav-item" data-toggle="tooltip" data-placement="right" title="Add new users to the system">
<a class="nav-link" href="register.php">
<i class="fa fas fa-user"></i>
<span class="nav-link-text">Register Users</span>
</a>
</li>
<li class="nav-item" data-toggle="tooltip" data-placement="right" title="Accept orders and refunds">
<a class="nav-link" href="pos.php">
<i class="fa fas fa-money"></i>
<span class="nav-link-text">POS</span>
</a>
</li>
</ul>
<ul class="navbar-nav ml-auto">

<li class="nav-item">
<form class="form-inline my-2 my-lg-0 mr-lg-2">
<div class="input-group">
<input class="form-control" type="text" placeholder="Search for...">
<span class="input-group-append">
<button class="btn btn-primary" type="button">
<i class="fa fa-search"></i>
</button>
</span>
</div>
</form>
</li>
<li class="nav-item">
<a class="nav-link" data-toggle="modal" data-target="#exampleModal" href='logout.php'>
<i class="fa fa-fw fa-sign-out"></i>Logout</a>
</li>
</ul>
</div>
</nav>
<!-- body of the file manager -->
<main class="content-wrapper">
<header class="container-fluid border-bottom">
	<h5 class="p-2"><strong> Folder Name</strong></h5>
</header> 
<section class="container-fluid row">
	<article id="toolbar" class="d-md-block col-md-4 col-lg-3 border-right border-left p-0">
		<button class='d-block btn btn-white container-fluid border-bottom p-4 text-left' data-toggle="modal" data-target="#uploadModal">
			<i class="fa fa-file mr-2"></i>
			<label for='newfile'><strong>New File</strong></label>
		</button>
		<button class='d-block btn btn-white container-fluid border-bottom p-4 text-left'>
			<i class="fa fa-check mr-2"></i> 
			<label for='approval'><strong>Pending Approvals</strong></label>
		</button>
	</article>
	<article id="filelist" class="container-fluid col-xs-12 col-md-8 col-lg-9">
		<div class="jumbotron row">
			<h5 class="p-4 col-xs-9"> Filename </h5>
			<h5 class="p-4 col-xs-2"> Date </h5>
			<h5 class="p-4 col-xs-1"> Action </h5>
		</div>
			<?php
		if(isset($_SESSION['username'])) { 
			$uname = $_SESSION['username']; 
			$stmt = mysqli_stmt_init($con);
		    if(mysqli_stmt_prepare($stmt,"SELECT * FROM filelist WHERE field3=?")){
		    	if(!mysqli_stmt_bind_param($stmt,"s",$uname))
		    	{	$_SESSION['error-message']="Binding parameters failed: ".mysqli_stmt_error($stmt);
		    		$_SESSION['redirect-url'] = $_SERVER['REQUEST_URI']; 
		    		header("Location: error_pages/error-message.php"); }

		    	if(!(mysqli_stmt_execute($stmt)))
				{	$_SESSION['error-message']="Execution failed: ".mysqli_stmt_error($stmt);
					$_SESSION['redirect-url'] = $_SERVER['REQUEST_URI'];
		    		header("Location: error_pages/error-message.php"); }

		    	$results = mysqli_stmt_get_result($stmt);

		    	if(mysqli_num_rows($results) == 0){ echo "<div class='container-fluid row'><span class='col-xs-12'>"."No results found"."</span></div>"; }
		    	else{
		    		while($data = mysqli_fetch_assoc($results)){	
		    			echo "<div scope='container-fluid row'>";
		    			echo "<form class='form-horizontal' method='post' action='delete-file.php'>";
		    			echo "<input type='text' class='border-0 bg-0' name='id' value=".$data['field1']." hidden>";
		    			echo "<input type='text' class='border-0 bg-0' name='project' value=".$data['field2']." hidden>";
		    			echo "<input type='text' class='border-0 bg-0' name='user' value=".$data['field3']." hidden>";
		    			echo "<span class='col-xs-7'><input type='text' class='border-0 bg-0' name='filename' value=".$data['field5']." readonly></span>";
		    			echo "<span class='col-xs-3'><input type='text' class='border-0 bg-0 col-md-hidden' name='date' value=".$data['field4']." readonly></span>";
		    			echo "<span class='col-xs-2'> <input class='btn btn-danger' type='submit' value='X'></span>";
		    			echo "</form>";
		    			echo "</div>";
		    			} 
		    		}	
		    }
		    else{ $_SESSION['error-message']="Statement preparation failed: ".mysqli_stmt_error($stmt);
	    	$_SESSION['redirect-url'] = $_SERVER['REQUEST_URI'];
	    	header("Location: error_pages/error-message.php"); }
	    }
	    else{ $_SESSION['error-message']="Login authentication failed: ".mysqli_stmt_error($stmt);
	    	$_SESSION['redirect-url'] = $_SERVER['REQUEST_URI'];
	    	header("Location: error_pages/error-message.php");
	    }
		?>
	</article>
	<article id="info" class="d-xs-none d-sm-none d-md-none col-lg-3" hidden>
		<div class="container-fluid"><img class='img-responsive p-4 center-block' src='favicon.ico' alt='fileimg'></div>
		<table>
			<thead>
				<th class="card-title"><h6>File 1</h6></th>
			</thead>
			<tbody>
				<tr scope='row'>
					<td class="border-right p-2"><label for='name' sr-only></label>Name</td>
					<td class="p-2"><label for='field1'>File 1</label></td>
				</tr>
				<tr>
					<td class="border-right p-2"><label for='file_size' sr-only></label>File size</td>
					<td class="p-2"><label for='field2'>47.80 kiB</label></td>
				</tr>
				<tr>
					<td class="border-right p-2"><label for='file_type' sr-only></label>File type</td>
					<td class="p-2"><label for='field3'>Php extension file</label></td>
				</tr>
				<tr>
					<td class="border-right p-2"><label for='last_modified' sr-only></label>Last modified</td>
					<td class="p-2"><label for='field4'>January 1, 2018</label></td>
				</tr>
				<tr>
					<td class="border-right p-2"><label for='owner' sr-only></label>Owner</td>
					<td class="p-2"><label for='field5'>Yamerrrooo</label></td>
				</tr>
				<tr scope='row'>
					<td class="border-right p-2"><label for='description' sr-only></label>Description</td>
					<td class="p-2"><label for='field6'>A nice file lmao</label></td>
				</tr>
			</tbody>
		</table>
	</article>
</section>
<div class="modal fade" id="uploadModal" tabindex="-1" role="dialog" aria-labelledby="uploadModalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalLabel">Upload a file</h5>
<button class="close" type="button" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<div class="modal-body">
	<?php
	echo "<form name=fileform method='post' class='form-horizontal mx-auto' action='insert-file.php' enctype='multipart/form-data'>
	<input type=text class='form-control mb-2' name=date value='".date('Y-m-d')."' hidden>
	<input type=text class='form-control mb-2' name=username value='$user' hidden>
	<input type=file class='bg-muted form-control padding mb-2' name='uploaded_file'>
	<div class='row'><div class='col-xs-12 mx-auto'><br>
	<input type='submit' class='btn btn-success' value='Submit'></div></div>";
	echo "</form></div>";
	?>
</div>
<div class="modal-footer">
<button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
</div>
</div>
</div>
</div>
</main>
</body>
<?php
}else{
	include('log.html');
}
?>
<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<!-- Custom scripts for this page-->
</html>