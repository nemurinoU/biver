<div class="page-footer">
			<h5>Copyrights</h5>
			<p> All data is in public domain unless otherwise stated. </p>
			
	</div>