﻿<?php
session_start();
$U="";
$P="";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
// ----------------security-----------------


function clean($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
$U=clean($_POST['username']);
$P=clean($_POST['password']);
$encp=md5($P);
if  (empty($U))  { echo "The USER field is required"; exit;}
if  (empty($P))  { echo "The PASS field is required"; exit;}
include "config.php";
$result = mysqli_query($con,"SELECT * FROM members where username='$U' and password='$encp' ");
if (!$result) { echo "'Could not run query: ' . mysqli_error()";   exit; }
$row =(mysqli_fetch_array($result));
 if ($row ) {    
// $_SESSION['level']=$row['level'];
$_SESSION['username']=$U;
header("location:file-user.php"); }
else { echo "<script language='javascript'>
	alert('Username and Password Did not Match');
	window.location = 'file-user.html';
	</script>";
 mysqli_close($con);} }
?>

